<?php
// created: 2016-10-19 03:58:18
$dictionary["te_Program_category"]["fields"]["te_program_category_te_pr_programs"] = array (
  'name' => 'te_program_category_te_pr_programs',
  'type' => 'link',
  'relationship' => 'te_program_category_te_pr_programs',
  'source' => 'non-db',
  'module' => 'te_pr_Programs',
  'bean_name' => 'te_pr_Programs',
  'vname' => 'LBL_TE_PROGRAM_CATEGORY_TE_PR_PROGRAMS_FROM_TE_PR_PROGRAMS_TITLE',
);
