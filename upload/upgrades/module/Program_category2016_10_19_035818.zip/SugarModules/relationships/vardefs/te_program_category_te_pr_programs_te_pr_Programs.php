<?php
// created: 2016-10-19 03:58:18
$dictionary["te_pr_Programs"]["fields"]["te_program_category_te_pr_programs"] = array (
  'name' => 'te_program_category_te_pr_programs',
  'type' => 'link',
  'relationship' => 'te_program_category_te_pr_programs',
  'source' => 'non-db',
  'module' => 'te_Program_category',
  'bean_name' => 'te_Program_category',
  'vname' => 'LBL_TE_PROGRAM_CATEGORY_TE_PR_PROGRAMS_FROM_TE_PROGRAM_CATEGORY_TITLE',
);
