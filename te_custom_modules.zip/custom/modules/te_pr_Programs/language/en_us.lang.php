<?php
// created: 2016-12-06 01:41:49
$mod_strings = array (
  'LBL_CLOSED_BATCH' => 'Closed Batch',
  'LBL_ENROLLMENT_IN_PROGRESS' => 'Enrollment in Progress',
  'LBL_CLASSES_IN_PROGRESS' => 'Classes in Progress',
  'LBL_TOTAL_P' => 'Total',
  'LBL_DIRECTOR_NAME' => 'Director Name',
  'LBL_CONTACT_NUMBER' => 'Contact Number',
  'LBL_EMAIL_ADDRESS' => 'Email Address',
  'LBL_EDITVIEW_PANEL1' => 'New Panel 1',
  'LBL_EDITVIEW_PANEL2' => 'New Panel 2',
  'LBL_NAME' => 'Program Name',
  'LBL_MOBILE_NUMBER' => 'Mobile Number',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_TE_PR_PROGRAMS_TE_BA_BATCH_1_FROM_TE_BA_BATCH_TITLE' => 'Batch',
);