<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2016-11-30 12:13:45
$dictionary["te_drip_campaign"]["fields"]["te_drip_campaign_te_drip_campaign_list"] = array (
  'name' => 'te_drip_campaign_te_drip_campaign_list',
  'type' => 'link',
  'relationship' => 'te_drip_campaign_te_drip_campaign_list',
  'source' => 'non-db',
  'module' => 'te_drip_campaign_list',
  'bean_name' => 'te_drip_campaign_list',
  'side' => 'right',
  'vname' => 'LBL_TE_DRIP_CAMPAIGN_TE_DRIP_CAMPAIGN_LIST_FROM_TE_DRIP_CAMPAIGN_LIST_TITLE',
);

?>