<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_TE_DRIP_CAMPAIGN_TE_DRIP_CAMPAIGN_LIST_FROM_TE_DRIP_CAMPAIGN_LIST_TITLE'] = 'Drip Campaign List';

?>