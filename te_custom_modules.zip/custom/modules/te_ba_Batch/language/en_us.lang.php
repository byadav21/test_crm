<?php
// created: 2016-10-28 01:29:34
$mod_strings = array (
  'LBL_CLASS_SCHEDULE' => 'class schedule',
  'LBL_TE_BA_BATCH_TE_INSTALLMENTS_1_FROM_TE_INSTALLMENTS_TITLE' => 'Installments',
  'LBL_EDITVIEW_PANEL1' => 'New Panel 1',
  'LBL_ENROLLED_STUDENTS' => 'Enrolled Students',
  'LBL_MINIMUM_ATTENDANCE_CRITERIA' => 'Minimum Attendance Criteria %',
  'LBL_DURATION' => 'Duration (In Months)',
  'LBL_NAME' => 'Batch Name',
  'LBL_MINIMUM_BATCH_SIZE' => 'Minimum Batch Size',
  'LBL_DESCRIPTION' => 'Description',
);