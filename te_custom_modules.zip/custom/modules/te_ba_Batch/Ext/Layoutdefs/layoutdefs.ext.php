<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-09-14 20:35:29
$layout_defs["te_ba_Batch"]["subpanel_setup"]['te_ba_batch_te_installments_1'] = array (
  'order' => 100,
  'module' => 'te_installments',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_TE_BA_BATCH_TE_INSTALLMENTS_1_FROM_TE_INSTALLMENTS_TITLE',
  'get_subpanel_data' => 'te_ba_batch_te_installments_1',
  'top_buttons' => 
  array (
    /* 0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ), */
  ),
);


//auto-generated file DO NOT EDIT
$layout_defs['te_ba_Batch']['subpanel_setup']['te_ba_batch_te_installments_1']['override_subpanel_name'] = 'te_ba_Batch_subpanel_te_ba_batch_te_installments_1';

?>