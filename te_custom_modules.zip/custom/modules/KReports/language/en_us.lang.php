<?php
// created: 2016-12-27 02:27:26
$mod_strings = array (
  'LBL_LIST_FORM_TITLE' => 'Report List',
  'LBL_SEARCH_FORM_TITLE' => 'Report Search',
);