<?php
// created: 2016-11-03 22:50:53
$mod_strings = array (
  'LBL_LAST_NAME' => 'Last Name',
);