<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-10-22 13:16:03
$layout_defs["AOS_Contracts"]["subpanel_setup"]['aos_contracts_te_impression_1'] = array (
  'order' => 100,
  'module' => 'te_impression',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_CONTRACTS_TE_IMPRESSION_1_FROM_TE_IMPRESSION_TITLE',
  'get_subpanel_data' => 'aos_contracts_te_impression_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    /* 1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ), */
  ),
);


//auto-generated file DO NOT EDIT
$layout_defs['AOS_Contracts']['subpanel_setup']['aos_contracts_te_impression_1']['override_subpanel_name'] = 'AOS_Contracts_subpanel_aos_contracts_te_impression_1';


//auto-generated file DO NOT EDIT
$layout_defs['AOS_Contracts']['subpanel_setup']['aos_contracts_documents']['override_subpanel_name'] = 'AOS_Contracts_subpanel_aos_contracts_documents';

?>