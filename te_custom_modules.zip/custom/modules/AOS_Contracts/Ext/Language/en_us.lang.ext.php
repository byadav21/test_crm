<?php 
 //WARNING: The contents of this file are auto-generated


$mod_strings['LBL_VENDOR'] = 'Vendor';
$mod_strings['LBL_VENDOR_TE_VENDOR_ID'] = 'Vendor (related  ID)';


$mod_strings['LBL_RATE'] = 'Rate Per Unit';

$mod_strings['LBL_TOTAL_CONTRACT_VALUE'] = 'Contract Value in Rs';



//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_AOS_CONTRACTS_TE_IMPRESSION_1_FROM_TE_IMPRESSION_TITLE'] = 'Impression';
$mod_strings['LBL_TE_VENDOR_AOS_CONTRACTS_1_FROM_TE_VENDOR_TITLE'] = 'Vendor';


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_AOS_CONTRACTS_TE_IMPRESSION_1_FROM_TE_IMPRESSION_TITLE'] = 'Actual Consumption';


$mod_strings['LBL_PO_NUMBER'] = 'PO Number';

?>