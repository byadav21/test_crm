<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $app_strings;
$dashletMeta['ForLiveBatchesonly'] = array('module'		=> 'te_utm',
										  'title'       => 'Live Top Lead Source', 
                                          'description' => 'Live Top Lead Source Display Staus',
                                          'icon'        => 'icon_te_ba_Batch_32.gif',
                                          'category'    => 'Module Views');
