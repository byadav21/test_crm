<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $app_strings;
       $dashletMeta['LiveBatchROI'] = array('module'	=> 'te_utm',
										  'title'       => 'Live Batch ROI', 
                                          'description' => 'Live Batch ROI For all Live Batches Spend Revenue CPA%',
                                          'icon'        => 'themes/default/images/icon_person.gif',
                                          'category'    => 'Module Views');
