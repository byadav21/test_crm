<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $app_strings;
       $dashletMeta['CampaignsROI'] = array('module'	=> 'te_utm',
										  'title'       => 'Campaigns ROI', 
                                          'description' => 'Campaigns ROI For Live Campaigns',
                                          'icon'        => 'themes/default/images/icon_Teams_32.gif',
                                          'category'    => 'Module Views');
