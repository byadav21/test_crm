<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $app_strings;
$dashletMeta['TopCampaignDashboard'] = array('module'		=> 'te_utm',
										  'title'       => 'Top Campaign Dash board', 
                                          'description' => 'Top Campaign Dash board',
                                          'icon'        => 'icon_te_ba_Batch_32.gif',
                                          'category'    => 'Module Views');
