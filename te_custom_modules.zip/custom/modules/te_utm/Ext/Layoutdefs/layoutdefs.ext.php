<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-11-24 12:25:58
$layout_defs["te_utm"]["subpanel_setup"]['te_utm_te_actual_campaign_1'] = array (
  'order' => 100,
  'module' => 'te_actual_campaign',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_TE_UTM_TE_ACTUAL_CAMPAIGN_1_FROM_TE_ACTUAL_CAMPAIGN_TITLE',
  'get_subpanel_data' => 'te_utm_te_actual_campaign_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


 // created: 2016-11-24 12:25:31
$layout_defs["te_utm"]["subpanel_setup"]['te_utm_te_budgeted_campaign_1'] = array (
  'order' => 100,
  'module' => 'te_budgeted_campaign',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_TE_UTM_TE_BUDGETED_CAMPAIGN_1_FROM_TE_BUDGETED_CAMPAIGN_TITLE',
  'get_subpanel_data' => 'te_utm_te_budgeted_campaign_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


//auto-generated file DO NOT EDIT
$layout_defs['te_utm']['subpanel_setup']['te_utm_te_budgeted_campaign_1']['override_subpanel_name'] = 'te_utm_subpanel_te_utm_te_budgeted_campaign_1';


//auto-generated file DO NOT EDIT
$layout_defs['te_utm']['subpanel_setup']['te_utm_te_utm_term_1']['override_subpanel_name'] = 'te_utm_subpanel_te_utm_te_utm_term_1';


//auto-generated file DO NOT EDIT
$layout_defs['te_utm']['subpanel_setup']['te_utm_te_actual_campaign_1']['override_subpanel_name'] = 'te_utm_subpanel_te_utm_te_actual_campaign_1';

?>