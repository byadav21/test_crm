<?php
$popupMeta = array (
    'moduleMain' => 'te_utm',
    'varName' => 'te_utm',
    'orderBy' => 'te_utm.name',
    'whereClauses' => array (
  'name' => 'te_utm.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
),
);
