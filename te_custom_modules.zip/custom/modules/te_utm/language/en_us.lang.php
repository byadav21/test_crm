<?php
// created: 2016-11-24 20:39:12
$mod_strings = array (
  'LBL_TE_UTM_TE_UTM_TERM_1_FROM_TE_UTM_TERM_TITLE' => 'UTM Term',
  'LBL_EDITVIEW_PANEL1' => 'undefined 1',
  'LBL_UTM_SOURCE' => 'UTM Source',
  'LBL_UTM_NAME' => 'UTM Name',
  'LBL_EDITVIEW_PANEL2' => 'undefined 2',
  'LNK_NEW_RECORD' => 'Create UTM',
  'LNK_LIST' => 'View UTM',
  'LNK_IMPORT_TE_UTM' => 'Import UTM',
  'LBL_LIST_FORM_TITLE' => 'UTM List',
  'LBL_SEARCH_FORM_TITLE' => 'Search UTM',
  'LBL_HOMEPAGE_TITLE' => 'My UTM',
  'LBL_TE_UTM_TE_ACTUAL_CAMPAIGN_1_FROM_TE_ACTUAL_CAMPAIGN_TITLE' => 'Actual Campaign Plan',
  'LBL_TE_UTM_TE_BUDGETED_CAMPAIGN_1_FROM_TE_BUDGETED_CAMPAIGN_TITLE' => 'Budgeted Campaign Plan',
);