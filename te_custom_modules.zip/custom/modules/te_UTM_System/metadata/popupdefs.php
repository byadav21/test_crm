<?php
$popupMeta = array (
    'moduleMain' => 'te_UTM_System',
    'varName' => 'te_UTM_System',
    'orderBy' => 'te_utm_system.name',
    'whereClauses' => array (
  'name' => 'te_utm_system.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
),
);
