<?php
// created: 2016-10-29 06:06:07
$mod_strings = array (
  'LNK_NEW_RECORD' => 'Create UTM Systems Systems',
  'LNK_LIST' => 'View UTM Systems Systems',
  'LNK_IMPORT_TE_UTM_SYSTEM' => 'Import UTM Systems Systems',
  'LBL_LIST_FORM_TITLE' => 'UTM System System List',
  'LBL_SEARCH_FORM_TITLE' => 'Search UTM System System',
  'LBL_HOMEPAGE_TITLE' => 'My UTM Systems Systems',
);