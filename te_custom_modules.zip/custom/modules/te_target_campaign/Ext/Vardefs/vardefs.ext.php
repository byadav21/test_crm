<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2016-12-23 06:33:04
$dictionary["te_target_campaign"]["fields"]["te_target_campaign_te_target_campaign_list_1"] = array (
  'name' => 'te_target_campaign_te_target_campaign_list_1',
  'type' => 'link',
  'relationship' => 'te_target_campaign_te_target_campaign_list_1',
  'source' => 'non-db',
  'module' => 'te_target_campaign_list',
  'bean_name' => 'te_target_campaign_list',
  'side' => 'right',
  'vname' => 'LBL_TE_TARGET_CAMPAIGN_TE_TARGET_CAMPAIGN_LIST_1_FROM_TE_TARGET_CAMPAIGN_LIST_TITLE',
);

?>