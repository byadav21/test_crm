<?php 
 //WARNING: The contents of this file are auto-generated


 // created: 2016-12-23 06:33:02
$layout_defs["te_target_campaign"]["subpanel_setup"]['te_target_campaign_te_target_campaign_list_1'] = array (
  'order' => 100,
  'module' => 'te_target_campaign_list',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_TE_TARGET_CAMPAIGN_TE_TARGET_CAMPAIGN_LIST_1_FROM_TE_TARGET_CAMPAIGN_LIST_TITLE',
  'get_subpanel_data' => 'te_target_campaign_te_target_campaign_list_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);


//auto-generated file DO NOT EDIT
$layout_defs['te_target_campaign']['subpanel_setup']['te_target_campaign_te_target_campaign_list_1']['override_subpanel_name'] = 'te_target_campaign_subpanel_te_target_campaign_te_target_campaign_list_1';

?>