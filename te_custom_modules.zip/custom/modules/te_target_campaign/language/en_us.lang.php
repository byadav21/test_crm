<?php
// created: 2016-12-23 06:35:29
$mod_strings = array (
  'LBL_TE_TARGET_CAMPAIGN_TE_TARGET_CAMPAIGN_LIST_1_FROM_TE_TARGET_CAMPAIGN_LIST_TITLE' => 'Target Campaign List',
);