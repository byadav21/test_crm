<?php
$module_name = 'te_target_campaign';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 
          array (
            'name' => 'program',
            'label' => 'LBL_PROGRAM',
            'comment' => '',
          ),
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'batch',
            'label' => 'LBL_BATCH',
            'comment' => '',
          ),
          1 => 
          array (
            'name' => 'vendor',
            'label' => 'LBL_VENDOR',
            'comment' => '',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'template',
            'label' => 'LBL_TEMPLATE',
            'comment' => '',
          ),
          1 => 'description',
        ),
      ),
    ),
  ),
);
?>
