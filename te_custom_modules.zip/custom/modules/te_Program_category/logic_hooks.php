<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
$hook_version = 1; 
$hook_array = Array(); 
// position, file, function 
$hook_array['process_record'] = Array(); 
$hook_array['process_record'][] = Array(9, 'programstotal','custom/modules/te_Program_category/listview_program_cet.php','listview_program_cetegory', 'display_program_cetegory');
$hook_array['before_save'][] = Array(3, 'duplicate', 'custom/modules/te_Program_category/duplicate_p.php','duplicate_category', 'duplicate_category_logic_method');  
?>
