<?php
// created: 2016-12-06 01:56:42
$mod_strings = array (
  'LBL_NAME' => 'Category Name',
  'LBL_TE_PROGRAM_CATEGORY_TE_PR_PROGRAMS_FROM_TE_PR_PROGRAMS_TITLE' => 'Programs',
);