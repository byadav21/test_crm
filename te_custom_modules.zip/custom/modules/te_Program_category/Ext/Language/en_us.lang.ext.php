<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_TE_PROGRAM_CATEGORY_TE_PR_PROGRAMS_FROM_TE_PR_PROGRAMS_TITLE'] = 'Programs';

?>