<?php
$popupMeta = array (
    'moduleMain' => 'te_Program_category',
    'varName' => 'te_Program_category',
    'orderBy' => 'te_program_category.name',
    'whereClauses' => array (
  'name' => 'te_program_category.name',
),
    'searchInputs' => array (
  1 => 'name',
),
    'searchdefs' => array (
  'name' => 
  array (
    'name' => 'name',
    'width' => '10%',
  ),
),
);
