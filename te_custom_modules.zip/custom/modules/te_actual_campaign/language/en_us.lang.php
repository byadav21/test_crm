<?php
// created: 2016-11-24 19:57:11
$mod_strings = array (
  'LBL_NAME' => 'UTM Name',
);