<?php 
 //WARNING: The contents of this file are auto-generated


 $action_view_map['statusreport'] = 'statusreport';
 

 $action_view_map['conversionreport'] = 'conversionreport';
 

 $action_view_map['salescyclereport'] = 'salescyclereport';
 

 $action_view_map['pipelinereport'] = 'pipelinereport';
 

 $action_view_map['gsvreport'] = 'gsvreport';
 


 $action_view_map['weeklyreport'] = 'weeklyreport';
 

 $action_view_map['dailyreport'] = 'dailyreport';
 
?>