<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $app_strings;
$dashletMeta['TopConversionbyLeadSource'] = array('module'		=> 'Leads',
										  'title'       => 'Top Conversion by Lead Source', 
                                          'description' => 'Top Conversion by LeadSource Dashlets',
                                          'icon'        => 'themes/default/images/icon_AOS_Products_32.gif',
                                          'category'    => 'Module Views');
