<?php 
 //WARNING: The contents of this file are auto-generated


 $action_view_map['managegroup'] = 'managegroup';
 


 $action_view_map['updategroup'] = 'updategroup';
 

?>