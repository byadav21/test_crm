<?php
if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
ini_set("display_errors",0);
class addPaymentClass{
	
	
	function checkDuplicateFunc($bean, $event, $argument){
		//~ echo "<pre>";
		//~ print_r($bean);die;
	}
	
	
}
