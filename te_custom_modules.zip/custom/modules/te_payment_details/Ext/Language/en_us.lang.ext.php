<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_LEADS_TE_PAYMENT_DETAILS_1_FROM_LEADS_TITLE'] = 'Leads';


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY

$mod_strings['LBL_PAYMENTTYPESOURCE'] = 'Payment Source';
$mod_strings['LBL_TRANSACTIONID'] = 'Transaction Id';

?>