<?php
// created: 2017-01-06 12:26:55
$GLOBALS['tabStructure'] = array (
  'LBL_GROUPTAB5_1473074494' => 
  array (
    'label' => 'LBL_GROUPTAB5_1473074494',
    'modules' => 
    array (
      0 => 'te_in_institutes',
      1 => 'te_pr_Programs',
      2 => 'te_ba_Batch',
      3 => 'te_Program_category',
    ),
  ),
  'LBL_GROUPTAB1_1474960120' => 
  array (
    'label' => 'LBL_GROUPTAB1_1474960120',
    'modules' => 
    array (
      0 => 'te_vendor',
      1 => 'AOS_Contracts',
      2 => 'te_utm',
      3 => 'te_budgeted_campaign',
      4 => 'te_actual_campaign',
      5 => 'te_drip_campaign',
      6 => 'te_target_campaign',
    ),
  ),
  'LBL_GROUPTAB7_1474959980' => 
  array (
    'label' => 'LBL_GROUPTAB7_1474959980',
    'modules' => 
    array (
      0 => 'Leads',
      1 => 'te_lead_assignment_rule',
      2 => 'te_disposition',
    ),
  ),
  'LBL_GROUPTAB3_1480929977' => 
  array (
    'label' => 'LBL_GROUPTAB3_1480929977',
    'modules' => 
    array (
      0 => 'KReports',
      1 => 'AOR_Reports',
      2 => 'Home',
    ),
  ),
);