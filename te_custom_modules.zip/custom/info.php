<?php
echo "Hello";
//~ echo date('Y-m-d');


?>
